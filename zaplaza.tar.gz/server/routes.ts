import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import crypto from "crypto";
import { storage } from "./storage";
import { authService, authMiddleware, adminMiddleware } from "./auth";
import { insertUserSchema, updateReportSchema, insertCondoSchema, insertStoreSchema, insertProductSchema, insertServiceProviderSchema, insertServiceSchema, insertDeliveryPersonSchema, insertOrderSchema, insertMarketplaceItemSchema, updateMarketplaceItemSchema, insertReportSchema } from "@shared/schema";
import { registerAdminRoutes } from "./admin-routes";
import "./types";

// ... (existing interfaces)

export async function registerRoutes(app: Express): Promise<Server> {

  // ✅ AUTH ROUTES
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const validation = insertUserSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ error: validation.error.flatten() });
      }

      const { password, ...userData } = validation.data;
      const hashedPassword = await authService.hashPassword(password);

      // Generate verification token
      const verificationToken = crypto.randomBytes(32).toString("hex");
      const verificationTokenExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

      const newUser = await storage.createUser({
        ...userData,
        password: hashedPassword,
        status: "pending_verification", // User must verify email first
        emailVerified: false,
        verificationToken,
        verificationTokenExpiry,
      });

      // In a real app, you would send an email. For this project, we log to console.
      const verificationLink = `http://localhost:5173/api/auth/verify-email?token=${verificationToken}`;
      console.log(`[EMAIL VERIFICATION] Link para ${newUser.username}: ${verificationLink}`);

      res.status(201).json({ 
        message: "Registro bem-sucedido! Um link de verificação foi enviado para o seu e-mail (verifique o console do servidor).",
        user: { id: newUser.id, username: newUser.username }
      });

    } catch (error: any) {
      if (error.message.includes("users_username_unique")) {
        return res.status(409).json({ error: "Nome de usuário já existe." });
      }
      if (error.message.includes("users_email_unique")) {
        return res.status(409).json({ error: "E-mail já está em uso." });
      }
      console.error("[REGISTER ERROR]", error);
      res.status(500).json({ error: "Erro interno no servidor ao tentar registrar." });
    }
  });

  app.get("/api/auth/verify-email", async (req: Request, res: Response) => {
    const loginUrl = new URL("/login", 'http://localhost:5173');
    try {
      const { token } = req.query;
      if (!token || typeof token !== 'string') {
        loginUrl.searchParams.set("error", "Token de verificação não fornecido.");
        return res.redirect(loginUrl.toString());
      }

      const user = await storage.getUserByVerificationToken(token);

      if (!user || !user.verificationTokenExpiry || user.verificationTokenExpiry < new Date()) {
        loginUrl.searchParams.set("error", "Token inválido ou expirado. Por favor, solicite um novo link de verificação.");
        return res.redirect(loginUrl.toString());
      }

      // Token is valid, update the user
      await storage.updateUser(user.id, {
        emailVerified: true,
        status: "active", // Or 'pending_approval' if you have that flow
        verificationToken: undefined,
        verificationTokenExpiry: undefined,
      });

      // Redirect to a confirmation page on the frontend
      loginUrl.searchParams.set("verified", "true");
      return res.redirect(loginUrl.toString());

    } catch (error) {
      console.error("[VERIFY EMAIL ERROR]", error);
      loginUrl.searchParams.set("error", "Erro ao verificar o e-mail.");
      return res.redirect(loginUrl.toString());
    }
  });
  
  // ... (the rest of the auth routes like /login and /me)
  registerAdminRoutes(app);
  // ... (the rest of the routes)

  const httpServer = createServer(app);
  return httpServer;
}
