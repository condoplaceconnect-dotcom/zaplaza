import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ✅ USERS TABLE
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: varchar("phone", { length: 20 }).notNull(),
  birthDate: varchar("birth_date", { length: 10 }), // YYYY-MM-DD format
  block: varchar("block", { length: 20 }), // Bloco (ex: "A", "B", "0" para funcionários)
  unit: varchar("unit", { length: 10 }), // Apartamento (ex: "101", "00" para porteiros)
  accountType: varchar("account_type", { length: 20 }).notNull().default("adult"), // adult, minor
  parentAccountId: varchar("parent_account_id"), // ID do adulto responsável (para menores)
  relationship: varchar("relationship", { length: 50 }), // filho, filha, dependente, etc (para menores)
  role: varchar("role", { length: 20 }).notNull().default("resident"), // resident, vendor, service_provider, delivery_person, staff, admin
  status: varchar("status", { length: 20 }).notNull().default("active"), // active, blocked_until_18
  condoId: varchar("condo_id"),
  emailVerified: boolean("email_verified").notNull().default(false), // Email verificado ou não
  verificationToken: varchar("verification_token", { length: 100 }), // Token para verificação de email
  verificationTokenExpiry: timestamp("verification_token_expiry"), // Expiração do token
  createdAt: timestamp("created_at").defaultNow(),
});

// ✅ CONDOMINIUMS TABLE
export const condominiums = pgTable("condominiums", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  zipCode: varchar("zip_code", { length: 10 }).notNull(),
  units: integer("units").notNull(),
  phone: varchar("phone", { length: 20 }),
  email: text("email"),
  description: text("description"),
  image: text("image"),
  status: varchar("status", { length: 20 }).notNull().default("pending"), // pending, approved, rejected
  createdAt: timestamp("created_at").defaultNow(),
});

// ✅ STORES TABLE (Lojas de Vendedores)
export const stores = pgTable("stores", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  image: text("image"),
  category: varchar("category", { length: 50 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  email: text("email"),
  status: varchar("status", { length: 20 }).notNull().default("active"),
  condoId: varchar("condo_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ✅ PRODUCTS TABLE (Produtos das Lojas)
export const products = pgTable("products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  storeId: varchar("store_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  image: text("image"),
  category: varchar("category", { length: 50 }),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  ingredients: text("ingredients"),
  available: boolean("available").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ✅ DELIVERY PERSONS TABLE (Entregadores)
export const deliveryPersons = pgTable("delivery_persons", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  name: text("name").notNull(),
  image: text("image"),
  phone: varchar("phone", { length: 20 }),
  block: varchar("block", { length: 20 }),
  unit: varchar("unit", { length: 10 }),
  status: varchar("status", { length: 20 }).notNull().default("offline"), // online, offline
  rating: decimal("rating", { precision: 3, scale: 2 }).default("0"),
  totalDeliveries: integer("total_deliveries").default(0),
  condoId: varchar("condo_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ✅ ORDERS TABLE (Pedidos)
export const orders = pgTable("orders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  condoId: varchar("condo_id").notNull(),
  storeId: varchar("store_id").notNull(),
  residentId: varchar("resident_id").notNull(),
  deliveryPersonId: varchar("delivery_person_id"),
  status: varchar("status", { length: 20 }).notNull().default("pending"), // pending, confirmed, preparing, ready, on_way, delivered, cancelled
  totalPrice: decimal("total_price", { precision: 10, scale: 2 }).notNull(),
  items: jsonb("items").notNull(), // array of {productId, name, price, quantity}
  deliveryAddress: text("delivery_address"),
  notes: text("notes"),
  tip: decimal("tip", { precision: 10, scale: 2 }).default("0"),
  rating: integer("rating"), // 1-5
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ✅ MARKETPLACE ITEMS TABLE (Vendas/Doações/Trocas entre moradores)
export const marketplaceItems = pgTable("marketplace_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  condoId: varchar("condo_id").notNull(),
  userId: varchar("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  images: jsonb("images").default([]), // array de URLs de imagens
  category: varchar("category", { length: 50 }), // roupas, móveis, eletrônicos, etc
  type: varchar("type", { length: 20 }).notNull(), // sale, donation, exchange
  price: decimal("price", { precision: 10, scale: 2 }), // null para doações
  block: varchar("block", { length: 20 }),
  unit: varchar("unit", { length: 10 }),
  status: varchar("status", { length: 20 }).notNull().default("available"), // available, sold, reserved, removed
  views: integer("views").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ✅ REPORTS TABLE (Denúncias)
export const reports = pgTable("reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  condoId: varchar("condo_id").notNull(),
  reporterId: varchar("reporter_id").notNull(), // quem denunciou
  targetType: varchar("target_type", { length: 30 }).notNull(), // product, store, service, delivery_person, user, marketplace_item, lost_and_found, message
  targetId: varchar("target_id").notNull(), // ID do item denunciado
  reason: varchar("reason", { length: 50 }).notNull(), // inappropriate_product, misconduct, fraud, harassment, offensive_content, prohibited_content, delivery_issue, abusive_price, rule_violation, danger, minor_misuse
  description: text("description").notNull(),
  evidence: jsonb("evidence").default([]), // screenshots, fotos, etc
  status: varchar("status", { length: 20 }).notNull().default("pending"), // pending, under_review, resolved, dismissed
  adminNotes: text("admin_notes"),
  resolvedBy: varchar("resolved_by"),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ✅ ZOD SCHEMAS
export const insertUserSchema = createInsertSchema(users)
  .pick({
    username: true,
    password: true,
    name: true,
    email: true,
    phone: true,
    birthDate: true,
    block: true,
    unit: true,
    accountType: true,
    parentAccountId: true,
    relationship: true,
    role: true,
    status: true,
    condoId: true,
    emailVerified: true,
    verificationToken: true,
    verificationTokenExpiry: true,
  })
  .extend({
    email: z.string().email({ message: "Formato de e-mail inválido." }).min(1, { message: "E-mail é obrigatório." }),
    phone: z.string().min(10, { message: "Telefone deve ter no mínimo 10 dígitos." }).max(20, { message: "Telefone muito longo." }),
    birthDate: z.string()
      .regex(/^\d{4}-\d{2}-\d{2}$/, "Data deve estar no formato YYYY-MM-DD")
      .refine((date) => !isNaN(new Date(date).getTime()), "Data de nascimento inválida")
      .refine((date) => new Date(date) <= new Date(), "Data de nascimento não pode ser no futuro")
      .refine((date) => {
        const age = new Date().getFullYear() - new Date(date).getFullYear();
        return age >= 0 && age <= 120;
      }, "Idade deve estar entre 0 e 120 anos"),
    block: z.string().min(1, "Bloco é obrigatório").max(20, "Bloco muito longo"),
    unit: z.string().min(1, "Unidade/Apartamento é obrigatório").max(10, "Unidade muito longa"),
  });

export const updateUserSchema = z.object({
  name: z.string().min(1, "Nome é obrigatório").optional(),
  email: z.string().email("Formato de e-mail inválido").optional(),
  phone: z.string().min(10, "Telefone deve ter no mínimo 10 dígitos").optional(),
  status: z.enum(["active", "blocked_until_18"]).optional(),
  role: z.enum(["resident", "vendor", "service_provider", "delivery_person", "staff", "admin"]).optional(),
});

export const updateReportSchema = z.object({
  status: z.enum(["pending", "under_review", "resolved", "dismissed"]),
  adminNotes: z.string().optional().nullable(),
});

// Schema base gerado pelo Drizzle
const baseInsertMarketplaceItemSchema = createInsertSchema(marketplaceItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Schema para inserção com validações customizadas
export const insertMarketplaceItemSchema = baseInsertMarketplaceItemSchema
  .extend({
    title: z.string().min(1, "Título é obrigatório").max(200, "Título muito longo"),
    type: z.enum(["sale", "donation", "exchange"], { required_error: "Tipo é obrigatório" }),
    price: z.string().nullable().optional(),
    category: z.string().max(100, "Categoria muito longa").nullable().optional(),
    description: z.string().max(2000, "Descrição muito longa").nullable().optional(),
    images: z.array(z.string()).nullable().optional(),
  })
  .refine(
    (data) => {
      if (data.type === "sale") {
        return !!data.price && parseFloat(data.price) > 0;
      }
      return true;
    },
    {
      message: "Preço é obrigatório para vendas",
      path: ["price"],
    }
  );

// Schema para atualização (todos os campos opcionais, exceto tipo)
export const updateMarketplaceItemSchema = z
  .object({
    title: z.string().min(1, "Título é obrigatório").max(200, "Título muito longo").optional(),
    description: z.string().max(2000, "Descrição muito longa").nullable().optional(),
    category: z.string().max(100, "Categoria muito longa").nullable().optional(),
    price: z.string().nullable().optional(),
    status: z.enum(["available", "sold", "reserved", "removed"]).optional(),
    images: z.array(z.string()).nullable().optional(),
  })
  .refine(
    (data) => {
      if (data.price !== undefined && data.price !== null) {
        const numPrice = parseFloat(data.price);
        return !isNaN(numPrice) && numPrice >= 0;
      }
      return true;
    },
    {
      message: "Preço inválido",
      path: ["price"],
    }
  );

export const insertCondoSchema = createInsertSchema(condominiums).omit({
  id: true,
  createdAt: true,
});

export const insertStoreSchema = createInsertSchema(stores).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDeliveryPersonSchema = createInsertSchema(deliveryPersons).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertReportSchema = createInsertSchema(reports).pick({
  condoId: true,
  reporterId: true,
  targetType: true,
  targetId: true,
  reason: true,
  description: true,
  evidence: true,
});

// ✅ TYPES
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Condominium = typeof condominiums.$inferSelect;
export type InsertCondominium = z.infer<typeof insertCondoSchema>;

export type Store = typeof stores.$inferSelect;
export type InsertStore = z.infer<typeof insertStoreSchema>;

export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type DeliveryPerson = typeof deliveryPersons.$inferSelect;
export type InsertDeliveryPerson = z.infer<typeof insertDeliveryPersonSchema>;

export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

export type MarketplaceItem = typeof marketplaceItems.$inferSelect;
export type InsertMarketplaceItem = z.infer<typeof insertMarketplaceItemSchema>;

export type Report = typeof reports.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;
